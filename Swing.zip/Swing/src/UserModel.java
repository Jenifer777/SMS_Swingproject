import java.io.Serializable;
import java.time.LocalDate;

//STEP 1 implements Serializable
public class UserModel implements Serializable  
{
	private String roll_no;
	private String name;
	private String dob;
    private String standard;
	private String email;
	private String mobile;
	private String gender;
	private String address;
	private String reg_no;
	private String date;
	private String Amount;
	public String getReg_no() {
		return reg_no;
	}

	public void setReg_no(String reg_no) {
		this.reg_no = reg_no;
	}



	private String status;
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	//STEP 2 CREATE NO ARG CONSTRUCTOR
	public UserModel() {
		super();
	}

	public String getRoll_no() {
		return roll_no;
	}



	public void setRoll_no(String roll_no) {
		this.roll_no = roll_no;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDob() {
		return dob;
	}



	public void setDob(String dob) {
		this.dob = dob;
	}



	public String getStandard() {
		return standard;
	}



	public void setStandard(String standard) {
		this.standard = standard;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getMobile() {
		return mobile;
	}



	public void setMobile(String mobile) {
		this.mobile = mobile;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}

}
