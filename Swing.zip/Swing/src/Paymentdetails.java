import java.awt.BorderLayout;
import java.awt.Container;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Paymentdetails extends JFrame{
	
	public Paymentdetails()
	{
		String payheading[]={"roll_no","Name","Date Of Birth","Class","Email","Mobile","Gender","Address","Date","Amount","STATUS"};
		String paydata[][];
		
		BackEndForDBOperation paybackobj = new BackEndForDBOperation();
		
		ArrayList<UserModel> payuserlist = paybackobj.fetchAllpaid(); 
		
		if(payuserlist.size() == 0)
		{
			JOptionPane.showMessageDialog(null, "NO RECORD FOUND");
		}
		else
		{
			//CREATE STRING 2D ARRAY ACCORDING TO THE NO OF OBJECT
			paydata = new String[payuserlist.size()][12];
			
			//RETRIVE OBJECT DATA & STORE IT IN THE 2D ARRAY
			int r=0;
			for(UserModel uobj : payuserlist)
			{
				paydata[r][0]=uobj.getRoll_no();
				paydata[r][1]=uobj.getName();
				paydata[r][2]=uobj.getDob();
				paydata[r][3]=uobj.getStandard();
				paydata[r][4]=uobj.getEmail();
				paydata[r][5]=uobj.getMobile();
				paydata[r][6]=uobj.getGender();
				paydata[r][7]=uobj.getAddress();
				paydata[r][8]=uobj.getDate();
				paydata[r][9]=uobj.getAmount();
				paydata[r][10]=uobj.getStatus();
				r++;
			}
			
			Container con=getContentPane();
			con.setLayout(new BorderLayout());
			
			//CREATE TABLE AND DISPLAY DATA
			JTable datatable=new JTable(paydata, payheading);
			JScrollPane jsp=new JScrollPane(datatable);
			
			con.add(new JLabel("PAYMENT DETAILS"),BorderLayout.NORTH);
			con.add(jsp,BorderLayout.CENTER);
			setSize(850, 300);
			setLocation(200, 200);
			setVisible(true);
	
		}
	}

	public static void main(String[] args) 
	{
		new Paymentdetails();

	}
}
