import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
create table logindetails
(
   userid varchar(20),
   password varchar(15)
);

insert into logindetails(userid,password) values('admin','pass');


create table userdetails
(
    name varchar(25),
    email varchar(25),
    mobile varchar(25),
    address varchar(25),
    city varchar(25),
    gender varchar(25),
    interests varchar(25),
    dob varchar(25)
);
*/

public class BackEndForDBOperation 
{
	public boolean loginCheck(String uid, String pass)
	{
	   PreparedStatement pst =null;
	   ResultSet rs = null;
	   Connection mysqlconnection = null;
	   
	   boolean status = false;
	   
	   try
	   {
		  mysqlconnection = DBMySQLConnect.getMySQLConnection();
		   	   
	      String logincheckquery = "select * from logindetails where userid=? and password=?";
		  	   
		  pst = mysqlconnection.prepareStatement(logincheckquery);
		  pst.setString(1, uid);
		  pst.setString(2, pass);
				   
		  rs = pst.executeQuery();
			
		  if(rs.next())
		  {
			status= true;
		  }
		}catch(SQLException e) 
		 {
		     e.printStackTrace();
		   	 //System.out.println("Can't Insert Record - Database Problem");
		 }
		 finally 
		 {
		    try 
		    {
			   if (pst != null)
			      pst.close();
			   if(rs != null)
				  rs.close();
			   if(mysqlconnection != null)
			      mysqlconnection.close();
			} catch (SQLException e) {e.printStackTrace();}
		  } 	
		  
		  return status;
     }
	
	public int insertRecord(UserModel userobj)
	{
	  PreparedStatement pst =null;
      Connection mysqlconnection = null;
      try
      {
   	     mysqlconnection = DBMySQLConnect.getMySQLConnection();
   	   
   	   //Step 3 PREPARE QUERY
   	     String insertquery = "insert into studentdetails(roll_no,name,dob,standard,email,mobile,gender,address) values(?,?,?,?,?,?,?,?)";
  	   
   	     pst = mysqlconnection.prepareStatement(insertquery);
		 pst.setString(1, userobj.getRoll_no());
		 pst.setString(2, userobj.getName());
		 pst.setString(3, userobj.getDob());
		 pst.setString(4, userobj.getStandard());
		 pst.setString(5, userobj.getEmail());
		 pst.setString(6, userobj.getMobile());
		 pst.setString(7, userobj.getGender());
		 pst.setString(8, userobj.getAddress());
		 
	   
		 int replycountfromdb = pst.executeUpdate();
		 
		 return replycountfromdb;
  
   	 }catch(SQLException e) 
      {
   		e.printStackTrace();
   		System.out.println("Can't Insert Record - Database Problem");
      }
      finally 
      {
       	try 
       	{
		  if (pst != null)
		    pst.close();
		  if(mysqlconnection != null)
		    mysqlconnection.close();
		} catch (SQLException e) {e.printStackTrace();}
	   } 
	return 0;
    }
	
	public int insertRecordPay(UserModel userobj)
	{
	  PreparedStatement pst =null;
      Connection mysqlconnection = null;
      try
      {
   	     mysqlconnection = DBMySQLConnect.getMySQLConnection();
   	   
   	   //Step 3 PREPARE QUERY
   	     String insertquery = "insert into payment(Reg_No,Date,Amount,STATUS) values(?,?,?,?)";
  	   
   	     pst = mysqlconnection.prepareStatement(insertquery);
		 pst.setString(1, userobj.getReg_no());
		 pst.setString(2, userobj.getDate());
		 pst.setString(3, userobj.getAmount());
		 pst.setString(4, userobj.getStatus());
		 
	   
		 int replycountfromdb = pst.executeUpdate();
		 
		 return replycountfromdb;
  
   	 }catch(SQLException e) 
      {
   		e.printStackTrace();
   		System.out.println("Can't Insert Record - Database Problem");
      }
      finally 
      {
       	try 
       	{
		  if (pst != null)
		    pst.close();
		  if(mysqlconnection != null)
		    mysqlconnection.close();
		} catch (SQLException e) {e.printStackTrace();}
	   } 
	return 0;
    }
		
	public int deleteRecord(String email)
    {
	   PreparedStatement pst =null;
	   Connection mysqlconnection = null;
	   try
	   {
	      mysqlconnection = DBMySQLConnect.getMySQLConnection();
	   	   
	      //Step 3 PREPARE QUERY
	      String delquery = "delete from studentdetails where email =?";
	  	   
	   	  pst = mysqlconnection.prepareStatement(delquery);
		  pst.setString(1, email);
			 
		  int replycountfromdb = pst.executeUpdate();
			 
		  return replycountfromdb;
	  
	   	 }catch(SQLException e) 
	      {
	   		e.printStackTrace();
	   		System.out.println("Can't Delete Record - Database Problem");
	      }
	      finally 
	      {
	       	try 
	       	{
			  if (pst != null)
			    pst.close();
			  if(mysqlconnection != null)
			    mysqlconnection.close();
			} catch (SQLException e) {e.printStackTrace();}
		   } 
		return 0;
		
    }
	public UserModel searchRecord(String emailid)
	{
	   PreparedStatement pst =null;
	   Connection mysqlconnection = null;
	   ResultSet rs = null;
	   UserModel uobj = new UserModel();
	   try
	   {
	      mysqlconnection = DBMySQLConnect.getMySQLConnection();
		   	   
	      String searchquery = "select * from studentdetails where email =?";
		  	   
		  pst = mysqlconnection.prepareStatement(searchquery);
		  pst.setString(1, emailid);
				 
		  rs = pst.executeQuery();
		  
		  
		  if(rs.next())
		  {
			  
			 uobj.setRoll_no(rs.getString(1)); 
			 uobj.setName(rs.getString(2));
			 uobj.setDob(rs.getString(3));
			 uobj.setDob(rs.getString(4));
			 uobj.setEmail(rs.getString(5));
			 uobj.setMobile(rs.getString(6));
			 uobj.setGender(rs.getString(7));  
			 uobj.setAddress(rs.getString(8));
			 
		
		  }
		  else
		  {
			  uobj = null;
		  }
		}catch(SQLException e){e.printStackTrace();}
		 finally 
		 {
		  	try 
		   	{
			  if (pst != null)
			    pst.close();
			  if(rs != null)
				rs.close();
			  if(mysqlconnection != null)
			    mysqlconnection.close();
			} catch (SQLException e) {e.printStackTrace();}
		  } 
	   return uobj;
		
	}
		
	public int updateRecord(UserModel userobj)
	{
	   PreparedStatement pst =null;
	   Connection mysqlconnection = null;
	   try
	   {
	      mysqlconnection = DBMySQLConnect.getMySQLConnection();
	   	   
	   	  String updatequery = "update studentdetails set name=?,mobile=?,address=? where email = ?";
	  	   
	   	  pst = mysqlconnection.prepareStatement(updatequery);
		  pst.setString(1, userobj.getName());
		  pst.setString(2, userobj.getMobile());
		  pst.setString(3, userobj.getAddress());
		  pst.setString(4, userobj.getEmail());
			 
		  int replycountfromdb = pst.executeUpdate();
			 
		  return replycountfromdb;
	  
	   	 }catch(SQLException e) 
	      {
	   		e.printStackTrace();
	   		System.out.println("Can't Insert Record - Database Problem");
	      }
	      finally 
	      {
	       	try 
	       	{
			  if (pst != null)
			    pst.close();
			  if(mysqlconnection != null)
			    mysqlconnection.close();
			} catch (SQLException e) {e.printStackTrace();}
		   } 
		return 0;
    }
	public ArrayList<UserModel> fetchAllRecord()
	{
	  PreparedStatement pst =null;
	  ResultSet rs = null;
	  Connection mysqlconnection = null;
	  
	  ArrayList<UserModel> emplist = new ArrayList<UserModel>();
	  
	  try
	  {
	    mysqlconnection = DBMySQLConnect.getMySQLConnection();
	   	   
        String fetchallquery = "select * from studentdetails";
	  	   
		pst = mysqlconnection.prepareStatement(fetchallquery);
			   
		rs = pst.executeQuery();
		
		while(rs.next())
		{
			UserModel uobj = new UserModel();
			uobj.setRoll_no(rs.getString(1));
			uobj.setName(rs.getString(2));
			uobj.setDob(rs.getString(3));
			uobj.setStandard(rs.getString(4));
			uobj.setEmail(rs.getString(5));
			uobj.setMobile(rs.getString(6));
			uobj.setGender(rs.getString(7));
			uobj.setAddress(rs.getString(8));

		
			//ADD Obj into ArrayList
			emplist.add(uobj);
		}
	  }catch(SQLException e){e.printStackTrace();}
	   finally 
	   {
	     try 
	     {
		   if (pst != null)
		    pst.close();
		   if (rs != null)
			rs.close();
		   if(mysqlconnection != null)
		    mysqlconnection.close();
		 } catch (SQLException e) {e.printStackTrace();}
	   } 	
	  return emplist;
	}
	public ArrayList<UserModel> fetchAllpaid()
	{
		
	  PreparedStatement pst =null;
	  ResultSet rs = null;
	  Connection mysqlconnection = null;
	  
	  ArrayList<UserModel> emplist = new ArrayList<UserModel>();
	  
	  try
	  {
	    mysqlconnection = DBMySQLConnect.getMySQLConnection();
	   	   
	    String fetchallquery = "SELECT studentdetails.roll_no roll_no,name,dob,standard,email,mobile,gender,address,Date,Amount,STATUS FROM  studentdetails,payment WHERE studentdetails.roll_no = payment.Reg_No";
 			   
          	   
		pst = mysqlconnection.prepareStatement(fetchallquery);
			   
		rs = pst.executeQuery();
		
		while(rs.next())
		{
			UserModel uobj = new UserModel();
			uobj.setRoll_no(rs.getString(1));
			uobj.setName(rs.getString(2));
			uobj.setDob(rs.getString(3));
			uobj.setStandard(rs.getString(4));
			uobj.setEmail(rs.getString(5));
			uobj.setMobile(rs.getString(6));
			uobj.setGender(rs.getString(7));
			uobj.setAddress(rs.getString(8));
			uobj.setDate(rs.getString(9));
			uobj.setAmount(rs.getString(10));
			uobj.setStatus(rs.getString(11));

		
			//ADD Obj into ArrayList
			emplist.add(uobj);
		}
	  }catch(SQLException e){e.printStackTrace();}
	   finally 
	   {
	     try 
	     {
		   if (pst != null)
		    pst.close();
		   if (rs != null)
			rs.close();
		   if(mysqlconnection != null)
		    mysqlconnection.close();
		 } catch (SQLException e) {e.printStackTrace();}
	   } 	
	  return emplist;
	}
	public ArrayList<UserModel> search(String mail)
	{
	  PreparedStatement pst =null;
	  ResultSet rs = null;
	  Connection mysqlconnection = null;
	  
	  ArrayList<UserModel> emplist = new ArrayList<UserModel>();
	  
	  try
	  {
	    mysqlconnection = DBMySQLConnect.getMySQLConnection();
	   	   
        String fetchallquery = "select * from studentdetails where email=?";
	  	   
		pst = mysqlconnection.prepareStatement(fetchallquery);
		pst.setString(1, mail);   
		rs = pst.executeQuery();
		
		while(rs.next())
		{
			UserModel uobj = new UserModel();
			uobj.setRoll_no(rs.getString(1));
			uobj.setName(rs.getString(2));
			uobj.setDob(rs.getString(3));
			uobj.setStandard(rs.getString(4));
			uobj.setEmail(rs.getString(5));
			uobj.setMobile(rs.getString(6));
			uobj.setGender(rs.getString(7));
			uobj.setAddress(rs.getString(8));

		
			//ADD Obj into ArrayList
			emplist.add(uobj);
		}
	  }catch(SQLException e){e.printStackTrace();}
	   finally 
	   {
	     try 
	     {
		   if (pst != null)
		    pst.close();
		   if (rs != null)
			rs.close();
		   if(mysqlconnection != null)
		    mysqlconnection.close();
		 } catch (SQLException e) {e.printStackTrace();}
	   } 	
	  return emplist;
	}
	
}
