import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EventObject;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class UFrame extends JFrame
{
	JFrame f=null;
	JMenuItem addmenuitemobj;
	JMenuItem delmenuitemobj;
	JMenuItem updatemenuitemobj;
	JMenuItem viewall;
	JMenuItem searchstd;
	JPanel p1;
	JPanel p2;
	JPanel p3;
	JPanel p4;
	JPanel p5;
	JPanel p6;
	JPanel p7;
	JTextField troll;
	JTextField tname;
    JComboBox day;
	JComboBox month;
	JComboBox year;
	JTextField tstandard;
	JTextField temail;
	JTextField tmobile;
	JRadioButton rmale;
	JRadioButton rfemale;
	JTextArea taddr;

	JButton bregister;
	JButton bclear;
    JTextField tf1;
    
    JTextField uemail;
	JTextField uname;
	JTextField umobile;
	JTextArea uaddr;
	JButton bdsearch;
	JButton bupdate;
	UserModel tempobj = null;
	
	JTextField tfn1;
	JButton bddsearch;
	
	JLabel Paylheading;
	JLabel viewsts;
	JTextField status;
	JButton bdddsearch;
		  
	public UFrame()
	{
		f = new JFrame("Student Management System");
		f.setLayout(new FlowLayout());
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		p4 = new JPanel();
		p5 = new JPanel();
		p6 = new JPanel();
		p7 = new JPanel();
		// 1. CREATE MENUBAR
		JMenuBar mbrobj = new JMenuBar();
		
		// 2. CREATE MENU
		JMenu ummenuobj = new JMenu("MANAGE STUDENT");
		JMenu ummenuobj1 = new JMenu("SEARCH");
		JMenu ummenuobj2 = new JMenu("FEES");
		JMenu ummenuobj3 = new JMenu("VIEW");
		
		
		//3. CREATE MENU ITEM
		addmenuitemobj = new JMenuItem("ADD STUDENT");
		addmenuitemobj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(true);
				p2.setVisible(false);
				p3.setVisible(false);
				p4.setVisible(false);
				p5.setVisible(false);
				p6.setVisible(false);
				p7.setVisible(false);
			}
		});
		
		delmenuitemobj = new JMenuItem("DELETE STUDENT");
		delmenuitemobj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(true);
				p3.setVisible(false);
				p4.setVisible(false);
				p5.setVisible(false);
				p6.setVisible(false);
				p7.setVisible(false);
			}
		});
		
		updatemenuitemobj = new JMenuItem("UPDATE STUDENT");
		updatemenuitemobj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(false);
				p3.setVisible(true);
				p4.setVisible(false);
				p5.setVisible(false);
				p6.setVisible(false);
				p7.setVisible(false);
			}
		});
				
		viewall = new JMenuItem("VIEW STUDENT");
		viewall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(false);
				p3.setVisible(false);
				p4.setVisible(true);
				p5.setVisible(false);
				p6.setVisible(false);
				p7.setVisible(false);
			}
		});
		
				
		searchstd = new JMenuItem("SEARCH STUDENT");
		searchstd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(false);
				p3.setVisible(false);
				p4.setVisible(false);
				p5.setVisible(true);
				p6.setVisible(false);
				p7.setVisible(false);
			}
		});
		
		JMenuItem payment = new JMenuItem("PAYMENTS");
		payment.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(false);
				p3.setVisible(false);
				p4.setVisible(false);
				p5.setVisible(false);
				p6.setVisible(true);
				p7.setVisible(false);
			}
		});
		JMenuItem paid = new JMenuItem("PAYMENT STATUS");
		paid.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				p1.setVisible(false);
				p2.setVisible(false);
				p3.setVisible(false);
				p4.setVisible(false);
				p5.setVisible(false);
				p6.setVisible(false);
				p7.setVisible(true);
			}
		});
		
		
		//4. ADD MENU ITEM INTO MENU
		ummenuobj.add(addmenuitemobj);
		ummenuobj.add(delmenuitemobj);
		ummenuobj.add(updatemenuitemobj);
		ummenuobj1.add(searchstd);
		ummenuobj2.add(payment);
		ummenuobj2.add(paid);
		ummenuobj3.add(viewall);
		
		//5. ADD MENU TO MENUBAR
		mbrobj.add(ummenuobj);
		mbrobj.add(ummenuobj1);
		mbrobj.add(ummenuobj2);
		mbrobj.add(ummenuobj3);

		f.setJMenuBar(mbrobj);
		
		JLabel lprojname = new JLabel("WELCOME!");
		f.add(lprojname);
		// panel 1

		
			Font fobj1 = new Font("comic sans ms",Font.BOLD,27);
			JLabel ltitle = new JLabel("ADD NEW STUDENT");
			ltitle.setBounds(140,20,100,50);
			ltitle.setFont(fobj1);
			
			Font fobj10 = new Font("comic sans ms",Font.BOLD,15);
			JLabel lroll = new JLabel("ROLL NO");
			lroll.setForeground(Color.BLACK);
			lroll.setFont(fobj10);
			troll = new JTextField();
			
			Font fobj2 = new Font("comic sans ms",Font.BOLD,15);
			JLabel lname = new JLabel("NAME");
			lname.setForeground(Color.BLACK);
			lname.setFont(fobj2);
			tname = new JTextField();
			
			JLabel ldob = new JLabel("DOB");
			ldob.setForeground(Color.BLACK);
			ldob.setFont(fobj2);
			String dvalue[]=new String[31];
			for(int i=0;i<=30;i++)
			{
				dvalue[i]=String.valueOf(i+1);
			}
			day=new JComboBox(dvalue);
			
			String mvalue[]=new String[12];
			for(int i=0;i<=11;i++)
			{
				mvalue[i]=String.valueOf(i+1);
			}
			month=new JComboBox(mvalue);
			
			String yvalue[]=new String[12];
			int cnt=0;
			for(int i=2015;i<=2025;i++)
			{
				yvalue[cnt]=String.valueOf(i);
				cnt++;	
			}
			year=new JComboBox(yvalue);
			
			JPanel dobpanel=new JPanel();
			dobpanel.add(day);
			dobpanel.add(month);
			dobpanel.add(year);
			
			JLabel lstandard = new JLabel("Class");
			lstandard.setForeground(Color.BLACK);
			lstandard.setFont(fobj2);
			tstandard = new JTextField();
			
			JLabel lemail = new JLabel("Email");
			lemail.setForeground(Color.BLACK);
			lemail.setFont(fobj2);
			temail = new JTextField();
			
			JLabel lmobile = new JLabel("MOBILE");
			lmobile.setForeground(Color.BLACK);
			lmobile.setFont(fobj2);
			tmobile = new JTextField();
			
			JLabel lgender = new JLabel("GENDER");
			lgender.setForeground(Color.BLACK);
			
			lgender.setFont(fobj2);
			rmale=new JRadioButton("Male");
			rfemale=new JRadioButton("Female");
			rmale.setSelected(true);
				
			//FOR DISPLAY RADIO BUTTON
	        JPanel gpanel=new JPanel();
			gpanel.add(rmale);
			gpanel.add(rfemale);
			
			//SELECT ONLY 1 OPTION
	        ButtonGroup rgroup=new ButtonGroup();
			rgroup.add(rmale);
			rgroup.add(rfemale);
			JLabel laddr = new JLabel("ADDRESS");
			laddr.setForeground(Color.BLACK);
			laddr.setFont(fobj2);
			taddr = new JTextArea(3,20);
			JScrollPane tapan=new JScrollPane(taddr);
			
			
			bregister = new JButton("Register");
			bregister.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					UserModel userobj = new UserModel();
					
					userobj.setRoll_no(troll.getText());
					userobj.setName(tname.getText());
					
					String d=(String)day.getSelectedItem();
			        String m=(String)month.getSelectedItem();
					String y=(String)year.getSelectedItem();
					String dob=d + "-" + m + "-" + y;
					userobj.setDob(dob);
					
					 userobj.setStandard(tstandard.getText());
				    userobj.setEmail(temail.getText());
				    userobj.setMobile(tmobile.getText());
				    
				    String gn="";
					if(rmale.isSelected())
					{
					    gn="Male";
					}
					else if(rfemale.isSelected())
					{
						gn="Female";
					}
					userobj.setGender(gn);
						
					
				    userobj.setAddress(taddr.getText());
						
					//STORE RECORD INTO DATABASE
					BackEndForDBOperation dbobj = new BackEndForDBOperation();
					
					int respfordboperation = dbobj.insertRecord(userobj);
					
					if (respfordboperation > 0)
					{
						JOptionPane.showMessageDialog(null, "RECORD ADDED SUCCESSFULLY");
					}
			  	    else
			  	    {
			  	    	JOptionPane.showMessageDialog(null, "TRY AGAIN");
			  	    }
					 dispose();
					  p1.setVisible(false);
				}
				});
	
			bclear = new JButton("Clear");
			bregister.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
			   dispose();
			  p1.setVisible(true);
				}
			} );
			
			
			p1.setLayout(new GridLayout(11,2));
			p1.setBounds(80,200,200,200);
			//p1.setBackground(Color.gray);
			
			p1.add(ltitle);p1.add(new Label("  "));
			p1.add(lroll);p1.add(troll);
			p1.add(lname);p1.add(tname);
			p1.add(ldob);p1.add(dobpanel);
			p1.add(lstandard);p1.add(tstandard);
			p1.add(lemail);p1.add(temail);
			p1.add(lmobile);p1.add(tmobile);
			p1.add(lgender);p1.add(gpanel);
     		p1.add(laddr);p1.add(tapan);
			p1.add(bregister);p1.add(bclear);
					
			f.getContentPane().add(p1);
			

		
			
		//***************************************************
	    // Delete frame
			
			Font f1 = new Font("Arial", Font.BOLD, 25);
			Font fobnj1 = new Font("comic sans ms",Font.BOLD,27);
			JLabel lheading = new JLabel("DELETE USER");
			//lheading.setBounds(180, 40, 200, 30);
			lheading.setFont(fobnj1);
			
			JLabel l1 = new JLabel("EMAIL ID");
			//l1.setBounds(70, 90, 100, 20);
			l1.setFont(f1);
			//l1.setForeground(Color.BLUE);
			
			tf1 = new JTextField();
			//tf1.setBounds(170, 90, 200, 20);
			tf1.setFont(f1);
					
			JButton bsearch = new JButton("DELETE");
			bsearch.setBounds(180, 300, 120, 25);
			bsearch.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) 
				{
			       BackEndForDBOperation dbobj = new BackEndForDBOperation();
					
			       String email = tf1.getText();
				   
			       int respfordboperation = dbobj.deleteRecord(email);
					
				   if (respfordboperation > 0)
				   {
					 JOptionPane.showMessageDialog(null, "DELETED RECORD SUCCESS");
					 tf1.setText("");
				   }
			  	   else
			  	   {
			  	    	JOptionPane.showMessageDialog(null, "INVALID EMAIL ID");
			  	   }
				}
			
			});
	
	   	p2.setLayout(new GridLayout(5,2));
		p2.setBounds(150,400,200,200);
	   	 
	   	p2.add(lheading); p2.add(new JLabel("  "));p2.add(l1); 
		p2.add(tf1);p2.add(new JLabel("  "));p2.add(new JLabel("   "));p2.add(bsearch);
		// Add lable L to JPanel P
	     	 
	   	f.getContentPane().add(p2); // Add panel P to JFrame f
	   	
	   	//**********************************************************************
	   	//update frame
	   	
	   	Font fobj5 = new Font("comic sans ms",Font.BOLD,27);
		JLabel Utitle = new JLabel("UPDATE USER");
		Utitle.setFont(fobj5);

		
		Font fobj6 = new Font("comic sans ms",Font.BOLD,15);
		JLabel Uemail = new JLabel("EMAIL");
		//Uemail.setForeground(Color.RED);
		Uemail.setFont(fobj6);
		uemail = new JTextField();
				
		JLabel Uname = new JLabel("NAME");
		//Uname.setForeground(Color.RED);
		Uname.setFont(fobj2);
		uname = new JTextField();
				
		JLabel Umobile = new JLabel("MOBILE");
		//Umobile.setForeground(Color.RED);
		Umobile.setFont(fobj2);
		umobile = new JTextField();
		
		JLabel Uaddr = new JLabel("ADDRESS");
		//Uaddr.setForeground(Color.RED);
		Uaddr.setFont(fobj2);
		uaddr = new JTextArea(3,20);
		JScrollPane tapan1=new JScrollPane(uaddr);
		
		bdsearch = new JButton("SEARCH");
		bupdate = new JButton("UPDATE");
		bupdate.setEnabled(false);
		bdsearch.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) 
		{
		   BackEndForDBOperation bobj = new BackEndForDBOperation();
		   if(e.getSource() == bdsearch)
		   {
	    	   UserModel uobj = bobj.searchRecord(uemail.getText().trim());
			   
			   if(uobj != null)
			   {
			      uemail.setText(uobj.getEmail());
			      uemail.setEditable(false);
			   
			      uname.setText(uobj.getName());
			      umobile.setText(uobj.getMobile());
			      uaddr.setText(uobj.getAddress());
			      
			      bupdate.setEnabled(true);
			      bdsearch.setEnabled(false);
			   }
			   else
			   {
				   JOptionPane.showMessageDialog(null, "INVALID EMAIL ID");
				   uemail.setText("");
			   }
				 
		   }
		   }
		
		});
		
		bupdate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
			   BackEndForDBOperation bobj = new BackEndForDBOperation();
			   if(e.getSource() == bupdate)
			   {
				   UserModel tempobj = new UserModel();
					 
				   //UPDATE TEMP OBJCET WITH NEW/UPDATED VALUE
				   tempobj.setEmail(uemail.getText());
				   tempobj.setName(uname.getText());
				   tempobj.setMobile(umobile.getText());
				   tempobj.setAddress(uaddr.getText());
				   
				   int noofrecoedupdated = bobj.updateRecord(tempobj);
				   
				   if (noofrecoedupdated > 0)
					{
						JOptionPane.showMessageDialog(null, "UPDATE SUCCESS");
						 uname.setText("");
					      umobile.setText("");
					      uaddr.setText("");
					}
			  	    else
			  	    {
			  	    	JOptionPane.showMessageDialog(null, "TRY AGAIN");
			  	    }
			 		dispose();
					//new p3(); 
				}
		    	}
			 });
		
		p3.setLayout(new GridLayout(6,2));
		p3.setBounds(150,400,400,200);
		
		p3.add(Utitle);p3.add(new JLabel("  "));
		p3.add(Uemail);p3.add(uemail);
		p3.add(Uname);p3.add(uname);
		p3.add(Umobile);p3.add(umobile);
		p3.add(Uaddr);p3.add(tapan1);
		p3.add(bdsearch);p3.add(bupdate);
	   	
		// Add lable L to JPanel P
	     	 
	   	f.getContentPane().add(p3);
	   	
	   	//********************************************************************
	   	//view all
	   	
	   	String heading[]={"roll_no","Name","Date Of Birth","Class","Email","Mobile","Gender","Address"};
		String data[][];
		
		BackEndForDBOperation backobj = new BackEndForDBOperation();
		
		ArrayList<UserModel> userlist = backobj.fetchAllRecord(); 
		
		if(userlist.size() == 0)
		{
			JOptionPane.showMessageDialog(null, "NO RECORD FOUND");
		}
		else
		{
			//CREATE STRING 2D ARRAY ACCORDING TO THE NO OF OBJECT
			data = new String[userlist.size()][8];
			
			//RETRIVE OBJECT DATA & STORE IT IN THE 2D ARRAY
			int r=0;
			for(UserModel uobj : userlist)
			{
				data[r][0]=uobj.getRoll_no();
				data[r][1]=uobj.getName();
				data[r][2]=uobj.getDob();
				data[r][3]=uobj.getStandard();
				data[r][4]=uobj.getEmail();
				data[r][5]=uobj.getMobile();
				data[r][6]=uobj.getGender();
				data[r][7]=uobj.getAddress();
				r++;
			}
			
			p4.setLayout(new BorderLayout());
			
			//CREATE TABLE AND DISPLAY DATA
			JTable datatable=new JTable(data, heading);
			JScrollPane jsp=new JScrollPane(datatable);
			
			p4.add(new JLabel("All USER DETAILS"),BorderLayout.NORTH);
			p4.add(jsp,BorderLayout.CENTER);
		}
		
		f.getContentPane().add(p4);
	   	//********************************************************************
	   	//Search frame
		
	
	
      Font fn1 = new Font("Arial", Font.BOLD, 15);
		
		JLabel Slheading = new JLabel("SEARCH");
		Font fn2 = new Font("Arial", Font.BOLD, 25);
		Slheading.setFont(fn2);
		
		JLabel ln1 = new JLabel("EMAIL ID");
		ln1.setFont(fn1);
	
		
		tfn1 = new JTextField(20);
		tfn1.setFont(fn1);
				
		JButton bddsearch = new JButton("SEARCH");
		bddsearch.setBounds(125, 125, 100, 25);
		bddsearch.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) 
		{
	       		
	       String email = tfn1.getText();
	               
		     new Showsearch(email);
		     tfn1.setText("");
		     }
        });
		
	
		
		p5 = new JPanel();
		p5.setLayout(new GridLayout(6,2));
		p5.setBounds(150,400,200,200);
	   	 
		p5.add(Slheading);
		p5.add(new JLabel(""));
		p5.add(ln1);p5.add(tfn1);p5.add(new JLabel(""));
		p5.add(bddsearch);
		// Add lable L to JPanel P
	     	 
	   	f.getContentPane().add(p5);
   
	   	//student payments panel
	   	
	   	
	   	
		JLabel lPtitle = new JLabel("ADD STUDENT PAYMENTS");
		lPtitle.setBounds(140,20,100,50);
		lPtitle.setFont(fobj1);
		lPtitle.setForeground(Color.BLUE);
		
		JLabel lProll = new JLabel("Roll No");
		lProll.setForeground(Color.BLACK);
		lProll.setFont(fobj10);
		JTextField tpay = new JTextField();
		
		
		JLabel lday = new JLabel("Date");
		lday.setForeground(Color.BLACK);
		lday.setFont(fobj2);
		String ddvalue[]=new String[31];
		for(int i=0;i<=30;i++)
		{
			dvalue[i]=String.valueOf(i+1);
		}
		day=new JComboBox(dvalue);
		
		String mmvalue[]=new String[12];
		for(int i=0;i<=11;i++)
		{
			mvalue[i]=String.valueOf(i+1);
		}
		month=new JComboBox(mvalue);
		
		String yyvalue[]=new String[12];
		int cant=0;
		for(int i=2015;i<=2025;i++)
		{
			yvalue[cnt]=String.valueOf(i);
			cant++;	
		}
		year=new JComboBox(yvalue);
		
		JPanel dlpaypanel=new JPanel();
		dlpaypanel.add(day);
		dlpaypanel.add(month);
		dlpaypanel.add(year);
		
		JLabel lamt = new JLabel("Amount");
		lamt.setForeground(Color.BLACK);
		lamt.setFont(fobj10);
		JTextField tamt = new JTextField();
		
		JLabel lhob = new JLabel("Status");
		lhob.setFont(fobj2);
		String hpay[]={"Pending","Paid"};
		JComboBox paysts = new JComboBox(hpay);
		
		//FOR DISPLAY RADIO 
		
		JButton bsubmit = new JButton("Payment");
		bsubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				UserModel userobj = new UserModel();
				
				userobj.setReg_no(tpay.getText());
				
				String d=(String)day.getSelectedItem();
		        String m=(String)month.getSelectedItem();
				String y=(String)year.getSelectedItem();
				String dob=d + "-" + m + "-" + y;
				userobj.setDate(dob);
				
				userobj.setAmount(tamt.getText());
		  	    userobj.setStatus((String)paysts.getSelectedItem());
									
				//STORE RECORD INTO DATABASE
				BackEndForDBOperation dbobj = new BackEndForDBOperation();
				
				int respfordboperation = dbobj.insertRecordPay(userobj);
				
				if (respfordboperation > 0)
				{
					JOptionPane.showMessageDialog(null, "PAYMENT ADDED SUCCESSFULLY");
				}
		  	    else
		  	    {
		  	    	JOptionPane.showMessageDialog(null, "TRY AGAIN");
		  	    }
				 dispose();
				  p1.setVisible(false);
			}
			});

		JButton bbclear = new JButton("Clear");
		bbclear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		   dispose();
		  p6.setVisible(true);
			}
		} );
		
		p6.setLayout(new GridLayout(10,2));
		p6.setBounds(80,200,500,300);
		//p1.setBackground(Color.gray);
		
		p6.add(lPtitle);p6.add(new Label("  "));
		p6.add(lProll);p6.add(tpay);
		p6.add(lday);p6.add(dlpaypanel);
		p6.add(lamt);p6.add(tamt);
		p6.add(lhob);p6.add(paysts);p6.add(new Label("  "));p6.add(new Label("  "));
		p6.add(bsubmit);p6.add(bbclear);

				
		f.getContentPane().add(p6);
		
		//PAYMENT DETAILS PANEL
		
		String payheading[]={"roll_no","Name","Date Of Birth","Class","Email","Mobile","Gender","Address","Date","Amount","STATUS"};
		String paydata[][];
		
		BackEndForDBOperation paybackobj = new BackEndForDBOperation();
		
		ArrayList<UserModel> payuserlist = paybackobj.fetchAllpaid(); 
		
		if(payuserlist.size() == 0)
		{
			JOptionPane.showMessageDialog(null, "NO RECORD FOUND");
		}
		else
		{
			//CREATE STRING 2D ARRAY ACCORDING TO THE NO OF OBJECT
			paydata = new String[payuserlist.size()][12];
			
			//RETRIVE OBJECT DATA & STORE IT IN THE 2D ARRAY
			int r=0;
			for(UserModel uobj : payuserlist)
			{
				paydata[r][0]=uobj.getRoll_no();
				paydata[r][1]=uobj.getName();
				paydata[r][2]=uobj.getDob();
				paydata[r][3]=uobj.getStandard();
				paydata[r][4]=uobj.getEmail();
				paydata[r][5]=uobj.getMobile();
				paydata[r][6]=uobj.getGender();
				paydata[r][7]=uobj.getAddress();
				paydata[r][8]=uobj.getDate();
				paydata[r][9]=uobj.getAmount();
				paydata[r][10]=uobj.getStatus();
				r++;
			}
			

			p7.setLayout(new BorderLayout());
			p7.setBounds(140,50,400,1000);
			
			//CREATE TABLE AND DISPLAY DATA
			JTable datatable=new JTable(paydata, payheading);
			JScrollPane jsp=new JScrollPane(datatable);
			
			p7.add(new JLabel("PAYMENT DETAILS"),BorderLayout.NORTH);
			p7.add(jsp,BorderLayout.CENTER);
  
		}
		
		f.getContentPane().add(p7);
		
	   	p1.setVisible(false);
	   	p2.setVisible(false);
		p3.setVisible(false);
		p4.setVisible(false);
		p5.setVisible(false);
		p6.setVisible(false);
		p7.setVisible(false);
		
	   	f.setSize(800,600);
	   	f.setLocation(180, 80);
	   	f.setVisible(true);
	}
} 
 public class MainFrame 
{
	public static void main(String[] args) 
	{
		UFrame obj = new UFrame();
	}
}